/** Automatically generated file. DO NOT MODIFY */
package com.atr.andar;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}