package com.atr.andar;

public class Config {
	public final static boolean DEBUG = false;
}
