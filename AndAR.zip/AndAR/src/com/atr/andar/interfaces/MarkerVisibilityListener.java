package com.atr.andar.interfaces;

/**
 * gets notified 
 * @author Tobi
 *
 */
public interface MarkerVisibilityListener {
	public void makerVisibilityChanged(boolean visible);
}
